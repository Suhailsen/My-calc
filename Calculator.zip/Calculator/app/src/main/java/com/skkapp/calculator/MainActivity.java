package com.skkapp.calculator;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.ClipboardManager;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;



public class MainActivity extends Activity {

	private LinearLayout linear1;
	private TextView output;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private ImageView num7;
	private ImageView num8;
	private ImageView num9;
	private ImageView clear;
	private ImageView num4;
	private ImageView num5;
	private ImageView num6;
	private ImageView plus;
	private ImageView minus;
	private ImageView num1;
	private ImageView num2;
	private ImageView num3;
	private ImageView multiply;
	private ImageView divide;
	private ImageView num0;
	private ImageView backspace;
	private ImageView equal;
	private TextView textview1;
	
	private double operator = 0;
	private double value1 = 0;
	private double value2 = 0;



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		initialize();
		initializeLogic();
	}

	private void  initialize() {
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		output = (TextView) findViewById(R.id.output);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		num7 = (ImageView) findViewById(R.id.num7);
		num8 = (ImageView) findViewById(R.id.num8);
		num9 = (ImageView) findViewById(R.id.num9);
		clear = (ImageView) findViewById(R.id.clear);
		num4 = (ImageView) findViewById(R.id.num4);
		num5 = (ImageView) findViewById(R.id.num5);
		num6 = (ImageView) findViewById(R.id.num6);
		plus = (ImageView) findViewById(R.id.plus);
		minus = (ImageView) findViewById(R.id.minus);
		num1 = (ImageView) findViewById(R.id.num1);
		num2 = (ImageView) findViewById(R.id.num2);
		num3 = (ImageView) findViewById(R.id.num3);
		multiply = (ImageView) findViewById(R.id.multiply);
		divide = (ImageView) findViewById(R.id.divide);
		num0 = (ImageView) findViewById(R.id.num0);
		backspace = (ImageView) findViewById(R.id.backspace);
		equal = (ImageView) findViewById(R.id.equal);
		textview1 = (TextView) findViewById(R.id.textview1);


		num1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(1);
			}
		});
		num2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(2);
			}
		});
		num3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(3);
			}
		});
		num4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(4);
			}
		});
		num5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(5);
			}
		});
		num6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(6);
			}
		});
		num7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(7);
			}
		});
		num8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(8);
			}
		});
		num9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(9);
			}
		});
		num0.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_displayNumber(0);
			}
		});
		backspace.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (operator == 0) {
					value1 = value1 / 10;
					output.setText(String.valueOf((long)(value1)));
				}
				else {
					value2 = value2 / 10;
					output.setText(String.valueOf((long)(value2)));
				}
			}
		});
		clear.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_clear();
			}
		});
		plus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (operator > 0) {
					_calc();
				}
				operator = 1;
			}
		});
		multiply.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (operator > 0) {
					_calc();
				}
				operator = 3;
			}
		});
		divide.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (operator > 0) {
					_calc();
				}
				operator = 4;
			}
		});
		minus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				if (operator > 0) {
					_calc();
				}
				operator = 2;
			}
		});
		equal.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) { 
				_calc();
			}
		});

	}

	private void  initializeLogic() {
		_clear();
	}


	private void _clear () {
		output.setText("0");
		operator = 0;
		value1 = 0;
		value2 = 0;
	}
	private void _displayNumber (final double _num) {
		if (operator == 0) {
			value1 = (value1 * 10) + _num;
			output.setText(String.valueOf((long)(value1)));
		}
		else {
			value2 = (value2 * 10) + _num;
			output.setText(String.valueOf((long)(value2)));
		}
	}
	private void _calc () {
		if (operator == 1) {
			value1 = value1 + value2;
		}
		if (operator == 2) {
			value1 = value1 - value2;
		}
		if (operator == 3) {
			value1 = value1 * value2;
		}
		if (operator == 4) {
			value1 = value1 / value2;
		}
		if (operator > 0) {
			value2 = 0;
			operator = 0;
			output.setText(String.valueOf((long)(value1)));
		}
	}




	// created automatically
	private void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}

	private int getRandom(int _minValue ,int _maxValue){
		Random random = new Random();
		return random.nextInt(_maxValue - _minValue + 1) + _minValue;
	}

	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
				_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}

	private float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}

	private int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}

	private int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}


}
